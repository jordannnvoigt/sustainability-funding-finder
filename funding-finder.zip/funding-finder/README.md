# Sustainability Funding Finder

AI-powered tool that helps people find federal, state, utility, and financing options
for sustainability and clean energy projects. Built to embed on Substack.

---

## Deploy to Vercel (free, ~10 minutes)

### Step 1 — Get your Anthropic API key
1. Go to https://console.anthropic.com
2. Click **API Keys** → **Create Key**
3. Copy the key (starts with `sk-ant-...`) — you won't see it again

### Step 2 — Put the project on GitHub
1. Create a free account at https://github.com if you don't have one
2. Click **+** → **New repository** → name it `funding-finder` → **Create**
3. Upload this entire folder (drag and drop the files onto the GitHub page)
   - `api/fund.js`
   - `public/index.html`
   - `vercel.json`
   - `package.json`

### Step 3 — Deploy on Vercel
1. Go to https://vercel.com and sign in with GitHub
2. Click **Add New Project** → select your `funding-finder` repo → **Import**
3. Under **Build & Output Settings**, set:
   - **Output Directory**: `public`
   - (Leave everything else as default)
4. Click **Deploy** — it will fail the first time because the API key isn't set yet

### Step 4 — Add your API key as an environment variable
1. In your Vercel project dashboard, go to **Settings** → **Environment Variables**
2. Add a new variable:
   - **Name**: `ANTHROPIC_API_KEY`
   - **Value**: your key from Step 1
3. Click **Save**
4. Go to **Deployments** → click the three dots on the latest → **Redeploy**

### Step 5 — Test it
Visit `https://your-project.vercel.app` — fill in the form and you should get real results.

---

## Embed on Substack

Substack supports iframes in posts. Once deployed, add this to any post or page:

```html
<iframe
  src="https://your-project.vercel.app"
  width="100%"
  height="900"
  frameborder="0"
  style="border-radius: 8px;"
></iframe>
```

**Note**: Substack iframe embeds work in the web version. Mobile app rendering varies.
For best results, link to the standalone URL as a button in your post alongside the iframe.

---

## Optional: Lock down CORS to your domain

Once live, open `api/fund.js` and change line 3 from:
```js
res.setHeader('Access-Control-Allow-Origin', '*');
```
to:
```js
res.setHeader('Access-Control-Allow-Origin', 'https://your-project.vercel.app');
```
This prevents other sites from using your API key.

---

## Cost estimate

Anthropic charges per token. Each query uses roughly 800–1,200 input tokens
and 500–900 output tokens.

- At current Claude Sonnet pricing (~$3/$15 per million tokens in/out):
  ~$0.015–0.025 per query
- 100 queries/month ≈ $1.50–$2.50
- 1,000 queries/month ≈ $15–$25

Set a usage limit at https://console.anthropic.com to protect yourself.

---

## Files

```
funding-finder/
├── api/
│   └── fund.js          ← Serverless function (runs on Vercel, holds API key)
├── public/
│   └── index.html       ← The entire frontend (self-contained)
├── vercel.json          ← Routing config
├── package.json         ← Node project config
└── README.md            ← This file
```
